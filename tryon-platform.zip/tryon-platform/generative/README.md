# Foto rejim (CatVTON, tegin, Colab)
1. Saytta (`web/index.html`) tik tur, **📸 Foto saqlaw** bas -> `person.png` júklenedi. (Eń jaqsı nátiyje ushın telefonda tik portret foto: yelkeden belge shekem, jaqtı bólme.)
2. Kiyim súwreti: taza, aq fonlı foto (dúkan fotosı yamasa óz kiyimińiz tegis jerde).
3. colab.research.google.com -> **File -> Upload notebook** -> `catvton_tryon.ipynb`.
4. **Runtime -> Change runtime type -> T4 GPU -> Save.**
5. Uyashıqlardı joqarıdan tómenge **Shift+Enter** menen isle. `person.png` tı, keyin kiyim súwretin(lerin) tańla.
6. Birinshi ret modeller júklenedi (bir neshe GB, kútiń).
7. Nátiyje `results.zip` retinde júklenedi.
Lisenziya: CC BY-NC-SA 4.0, tek komerciyasız. Diplomda CatVTON hám OpenTryOn dı derek retinde kórsetiń.
