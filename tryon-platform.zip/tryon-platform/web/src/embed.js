// Dúkan ishine qoyılatuǵın try-on: bir kiyim (img+prompt) menen, sessiya shegarası menen.
import { createDecartClient, models } from "https://esm.sh/@decartai/sdk";
const $ = id => document.getElementById(id), q = new URLSearchParams(location.search);
const S = q.get("s"), MAX = Number(q.get("max")) || 60, IMG = q.get("img"), PROMPT = q.get("prompt");
let rt = null, stream = null, timer = null, secs = 0;
const client = createDecartClient({ apiKeyProvider: async () => {
  const r = await fetch("/api/tokens", { method: "POST", headers: { "X-Session": S } });
  if (!r.ok) throw new Error("Token alınbadı"); return (await r.json()).apiKey; } });

async function garmentBlob() {
  const img = new Image(); img.src = `/api/garment?url=${encodeURIComponent(IMG)}&s=${encodeURIComponent(S)}`; await img.decode();
  const c = document.createElement("canvas"); c.width = c.height = 768; const g = c.getContext("2d");
  g.fillStyle = "#fff"; g.fillRect(0, 0, 768, 768);
  const k = Math.min(768 / img.width, 768 / img.height) * 0.9;
  g.drawImage(img, (768 - img.width * k) / 2, (768 - img.height * k) / 2, img.width * k, img.height * k);
  return new Promise(r => c.toBlob(r, "image/png"));
}
async function start() {
  try {
    $("start").disabled = true; $("status").textContent = "Jalǵanıp atır…";
    const model = models.realtime("lucy-vton-latest");
    stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { frameRate: model.fps, width: model.width, height: model.height } });
    rt = await client.realtime.connect(stream, { model, mirror: "auto", onRemoteStream: s => { $("out").srcObject = s; } });
    await rt.set({ prompt: PROMPT, image: await garmentBlob(), enhance: false });
    secs = 0; $("stop").disabled = false; $("status").textContent = "Tayar";
    timer = setInterval(() => { secs++; $("time").textContent = `${secs}/${MAX}s`; if (secs >= MAX) stop(); }, 1000);
  } catch (e) { $("status").textContent = "Qátelik: " + e.message; console.error(e); stop(); }
}
function stop() {
  clearInterval(timer); timer = null; try { rt?.disconnect(); } catch {}
  stream?.getTracks().forEach(t => t.stop());
  if (secs) fetch("/api/usage", { method: "POST", keepalive: true, headers: { "X-Session": S, "Content-Type": "application/json" }, body: JSON.stringify({ seconds: secs }) });
  secs = 0; rt = null; stream = null; $("start").disabled = false; $("stop").disabled = true;
}
$("start").onclick = start; $("stop").onclick = stop;
