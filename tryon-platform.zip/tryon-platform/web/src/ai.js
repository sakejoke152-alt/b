// AI rejim: Decart Lucy VTON (real waqıtlı generativ model). Pul/kredit sarıplanadı!
import { createDecartClient, models } from "https://esm.sh/@decartai/sdk";

const $ = id => document.getElementById(id);
const out = $("out"), status = $("status"), cost = $("cost"), catalogEl = $("catalog");
const MAX_SEC = Number(new URLSearchParams(location.search).get("max") || 90);   // avtomat toqtaw
const RATE = 0.02;                                                              // $/sek (hújjet boyınsha, 720p)
let rt = null, stream = null, timer = null, secs = 0, pending = null;

const client = createDecartClient({
  apiKeyProvider: async () => {
    const r = await fetch("/api/tokens", { method: "POST" });
    if (!r.ok) throw new Error("Token alınbadı: " + (await r.text()));
    return (await r.json()).apiKey;
  }
});

async function toPngBlob(url) {                    // SVG/PNG/JPG -> 768x768 PNG, aq fon
  const img = new Image(); img.src = url; await img.decode();
  const c = document.createElement("canvas"); c.width = c.height = 768;
  const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, 768, 768);
  const k = Math.min(768 / img.width, 768 / img.height) * 0.9;
  g.drawImage(img, (768 - img.width * k) / 2, (768 - img.height * k) / 2, img.width * k, img.height * k);
  return new Promise(r => c.toBlob(r, "image/png"));
}

async function apply(it) {
  const state = { prompt: it.prompt, enhance: false };
  if (it.sendImage) state.image = await toPngBlob(it.image);
  await rt.set(state);                              // set() butın halatın almastıradı
}

async function start() {
  try {
    $("start").disabled = true; status.textContent = "Jalǵanıp atır…";
    const model = models.realtime("lucy-vton-latest");
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false, video: { frameRate: model.fps, width: model.width, height: model.height } });
    rt = await client.realtime.connect(stream, {
      model, mirror: "auto", onRemoteStream: s => { out.srcObject = s; } });
    if (pending) await apply(pending);
    secs = 0; $("stop").disabled = false;
    timer = setInterval(() => {
      secs++; cost.textContent = ` ${secs}s · ≈ $${(secs * RATE).toFixed(2)} (avtomat toqtaydı: ${MAX_SEC}s)`;
      if (secs >= MAX_SEC) stop();
    }, 1000);
    status.textContent = "Tayar. Kiyim saylań.";
  } catch (e) { status.textContent = "Qátelik: " + e.message; console.error(e); stop(); }
}

function stop() {
  clearInterval(timer); timer = null;
  try { rt?.disconnect(); } catch {}
  stream?.getTracks().forEach(t => t.stop());
  rt = null; stream = null; $("start").disabled = false; $("stop").disabled = true;
  if (!status.textContent.startsWith("Qátelik")) status.textContent = "Toqtatıldı";
}

for (const it of await (await fetch("catalog-ai.json")).json()) {
  const b = document.createElement("button");
  b.className = "item"; b.setAttribute("aria-pressed", "false");
  b.innerHTML = `<img src="${it.image}" alt=""><span>${it.name}</span>`;
  b.onclick = async () => {
    document.querySelectorAll(".item[data-ai]").forEach(x => x.setAttribute("aria-pressed", "false"));
    b.setAttribute("aria-pressed", "true"); pending = it;
    if (rt) { status.textContent = "Qollanıp atır…"; try { await apply(it); status.textContent = "Tayar"; } catch (e) { status.textContent = "Qátelik: " + e.message; } }
  };
  b.dataset.ai = "1"; catalogEl.append(b);
}
$("start").onclick = start; $("stop").onclick = stop;
