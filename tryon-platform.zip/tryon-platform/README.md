# Try-On platforma (1-bosqısh: kamera + dene + kiyim overlay)

## Qalay iske qosıladı (Windows)
1. VS Code da `tryon-platform` papkasın ash.
2. Extensions → **Live Server** (Ritwick Dey) ornat.
3. `web/index.html` ge ońǵı túyme → **Open with Live Server**.
4. Brauzerde kameraǵa ruxsat ber. Yelkeńiz kórinsin.

Tek `file://` arqalı ashpań: ES modullar islemeydi, Live Server kerek.

## Papkalar
- `web/index.html` — bet
- `web/src/camera.js` — kamera
- `web/src/pose.js` — MediaPipe Pose (lite)
- `web/src/smooth.js` — titirewdi azaytıw
- `web/src/overlay.js` — kiyimdi yelkege sáykeslestiriw
- `web/src/main.js` — tiykarǵı ciklı
- `web/catalog.json` — kiyimler hám anchor nuqtaları
- `web/assets/garments/` — kiyim súwretleri (SVG/PNG)

## Sazlaw
- Kiyim jaman turıp qalsa: `catalog.json` da `scale` di 0.9-1.3 aralıǵında ózgert.
- Titirew kóp bolsa: `smooth.js` da `a` di kemeyt (mısalı 0.25).
