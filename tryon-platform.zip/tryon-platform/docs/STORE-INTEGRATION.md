# Dúkanlarǵa qosıw (SaaS): bir túyme, bir qatar kod

## Ideya
Qálegen kiyim dúkanı saytına **bir qatar script** qosadı. Hár kiyim betinde "Kiyip kóriw" túymesi payda boladı. Basılsa, kamera menen try-on ashıladı. Keyin dúkan **abonement** (podpiska) satıp aladı.

## Qalay isleydi
1. Dúkan saytına: `<script src=".../widget/tryon-widget.js" data-key="DUKAN-KILTI" defer>`.
2. Widget kiyim súwretin hám atın avtomat tabadı (og:image, schema.org Product). Kerek bolsa `data-image`, `data-prompt`, `data-target` menen qolda beriledi.
3. Basılǵanda widget bizdiń servergee `POST /api/session` jiberedi. Server **kilt + domen (Origin) + aylıq limit** tekseredi, 10 minutlıq qol qoyılǵan sessiya beredi.
4. Modal ishinde `embed.html` (iframe, kameraǵa ruxsat) ashıladı. Server Decart ushın waqıtsha token beredi, kiyim súwretin proksi arqalı alıp keledi.
5. Sessiya tawsılǵanda sekund esabı serverge jazıladı (`usage.json`).

## Nege AI rejim (hám AR emes)
Tez AR rejim hár kiyim ushın qolda anchor nuqtaların talap etedi. Kóp dúkan ushın bul bolmaydı. AI rejim qálegen kiyim súwreti menen isleydi, sonıń ushın dúkanlarǵa bir qatar kod penen qosıw múmkin. **AR** rejim: óz tańlanǵan kataloglar ushın (tegin, tez).

## Abonement rejesi (usınıs, bahaları tekseriw kerek)
- **Free:** 300 sekund/ay, 60 s sessiya (test ushın).
- **Standard / Pro:** kóbirek sekund hám analitika. Tólew: Payme/Click (qosıw múmkinligin tekseriw kerek).
- Esap: AI sessiyanıń öz bahası bar (≈ $0.02/s hújjet boyınsha). Abonement bahası sol bahadan joqarı bolıwı shárt.

## Qáwipsizlik
- Decart master kilti hesh qashan brauzerge bermeydi, tek waqıtsha token.
- Domen ruxsat dizimi (`origins`), aylıq limit, sessiya waqtı, proksi tek ruxsat etilgen xostlar (SSRF qorǵanıwı), súwret kólemi shegi.
- **Jeke ma'lumot:** kamera videosı AI modeline (sırtqı xızmet) jiberiledi. Paydalanıwshıǵa aldın ayqın xabar hám razılıq kerek, qaǵıyda matni jazılıwı shárt.
- MVP shegi: sekund esabın klient jiberedi (aldawǵa bolıwı múmkin). Keyin serverden tekseriw kerek.

## Hám keyin
Admin paneli (dúkan ózi statistika kóredi), Shopify/WooCommerce/Tilda plagini, LLM menen prompt jaratıw, DB (SQLite/Postgres), tólem.
