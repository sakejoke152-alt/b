# Qádem-qádem: 1-bósqıshtı iske qosıw (Windows)

## A. Bir ret tayarlıq
1. Zip tı Desktop qa shıǵar: zip ke ońǵı túyme -> **Extract All**.
2. **VS Code** ash -> **File -> Open Folder** -> `tryon-platform` papkasın tańla.
3. **Ctrl+Shift+X** bas (Extensions) -> izlewge `Live Server` jaz -> **Install** (avtor: Ritwick Dey).

## B. Iske qosıw
4. Shep tárepten `web` -> `index.html` fayldı ash.
5. Fayl ústinde ońǵı túyme -> **Open with Live Server**.
6. Chrome ashıladı (adres `127.0.0.1:5500`). Kamera soraǵanda **Allow** (Ruxsat) bas.
7. Ekrannıń tómen shepinde jazıw: "Model júklenip atır" -> bir neshe sekundtan keyin "Tayar".

## C. Ne kóriniwi kerek
8. Yelkeńiz kamerada kórinsin (ayaqqa shekem kerek emes).
9. Kók futbolka yelkeńizge jabısıp, qozǵalǵanda ergesedi.
10. Tómendegi kiyim túymesin bas: qızıl futbolkaǵa almasadı.

## D. Sazlaw
- Kiyim kishi/úlken bolsa: `web/catalog.json` da `"scale"` di 0.9-1.3 aralıǵında ózgert, saqla (Ctrl+S). Brauzer ózi jańalanadı.
- Kiyim titirese: `web/src/smooth.js` da `a = 0.4` di `0.25` qıl.

## E. Qátelik bolsa
- Chrome da **F12** -> **Console** tabı -> qızıl tekstti kóshirip jiber.
- "Qátelik: ..." xabarı ekranda shıqsa, sol tekstti jiber.

## F. Keyingi bósqıshlar (tártip)
1. Kepka (Face Landmarker)
2. Katalogtı jaqsılaw (jańa kiyimler, anchor sazlaw paneli)
3. Generativ foto rejim (OpenTryOn: CatVTON, Colab da)
4. Ólshew (FPS, anketa)
5. Hosting hám diplom

## G. Realistik kiyim qosıw (jańalaw)
Haqıyqıy kiyim fotosı mültfilm SVG den kóp jaqsı kórinedi.
1. Kiyimdi tegis jerge (tósek, jer) jayıp, joqarıdan tik foto al (yamasa dúkan fotosı).
2. Fonın al: **photopea.com** -> File -> Open -> Select -> Subject -> Layer -> Layer Mask -> Reveal Selection -> File -> Export As -> **PNG**.
3. PNG ni `web/assets/garments/` ge sal (mısalı `black-tee.png`).
4. `tools/anchor-picker.html` di Live Server menen ash, PNG tańla, 3 nuqtanı bas: shep yelke, ońǵı yelke, etek ortası.
5. Shıqqan `"anchors":{...}` qatardı `web/catalog.json` ge jańa kiyim retinde qos (ústindegi qatardı úlgi qıl).
6. Brauzerde **Ctrl+F5** bas.
Sazlaw: `lenK` (kiyim uzınlıǵı, 1.0-1.3), `torsoRatio` (belder kórinbese boyı, 1.4-1.8).

## H. 2-bósqısh: 3D kepka hám ko'zoynek (jańalaw)
1. Jańa zip ti ashıp, eski papkanıń ornına qoy. Live Server menen `web/index.html` ash, **Ctrl+F5**.
2. Tómendegi katalogtan **Qara ko'zoynek** yamasa **Kók kepka** túymesin bas. Bir waqıtta futbolka + kepka + ko'zoynek kiyiwge boladı. Qayta bassań, sheship qoyadı.
3. Birinshi iske qosıwda 3D zat bastıń aldında/artında jaman turıwı múmkin. **"3D zattı sazlaw"** bólimin ash hám sliderlerdi jılj:
   - *Joqarı-tómen* hám *Aldı-artı*: ornın túzet.
   - *Ólshem*: zat úlken/kishi bolsa.
   - *Kamera FOV*: bas burǵanda zat "sırǵıp" ketse 50-80 aralıǵında sına.
4. Jaqsı turǵanda tómendegi tekstti (`"offset":[...],"scale":...`) `catalog.json` degi sol zatqa kóshir, Ctrl+S.
5. **Tayar GLB model qosıw:** `.glb` fayldı `web/assets/models/` ge sal, `catalog.json` ge jańa qatar qos: `"model":"assets/models/atı.glb"`, `"slot":"hat"`. Model kórinbese, `scale` di 0.1, 10 yamasa 100 qılıp kór (modellerdiń birligi túrlishe). Lisenziyanı (CC0/CC-BY) tekseriń.

## I. 3-bósqısh: AI rejim (Decart Lucy VTON, real waqıtlı generativ)
Bul rejim kiyimdi haqıyqıy videoǵa jaqın etip kiyindiredi. **Internet hám Decart akkaunt kerek.** Pul/kredit sarıplanadı (hújjet boyınsha ≈ $0.02 sekundına; jańa akkauntqa tegin kredit beriledi, muǵdarın platform.decart.ai da kóriń).

### Bir ret tayarlıq
1. **Node.js LTS** ornat (nodejs.org, "Next" bas). Tekseriw: `cmd` -> `node --version`.
2. **platform.decart.ai** -> akkaunt -> **API key** jasaw. Kilitti hesh kimge hám GitHub qa jiberme.

### Iske qosıw (hár ret)
3. VS Code da Terminal -> New Terminal. Mına buyrıqlardı birin-birin jaz:
```
cd server
npm install
set DECART_API_KEY=seniń_kiltiń
npm start
```
(PowerShell bolsa `set` ornına: `$env:DECART_API_KEY="seniń_kiltiń"`)
4. Brauzerde **http://localhost:3000/ai.html** ash (Live Server emes, usı adres).
5. **▶ Baslaw** bas, kameraǵa ruxsat ber. Kiyimdi tańla.
6. **■ Toqtat** bas. Qalay bolsa da **90 sekundtan keyin avtomat toqtaydı** (kredit saqlaw ushın). Uzaǵıraq kerek bolsa: `ai.html?max=180`.

### Eskertpe
- Kiyim súwreti haqıyqıy foto bolsa, nátiyje kóp jaqsı (aq fonlı, taza kiyim). SVG mültfilm tek sınaq.
- Internet tezligi hám Decart serverine aralıq kechikiwge tásir etedi. Qorǵawdan aldın tekser.
- Demo ushın: 60-90 sekundlıq AI sessiya + rezerv ekran videosı jaz.

## J. 4-bósqısh: Dúkanlarǵa qosıw (widget)
1. `server` papkasında: `npm start` (DECART_API_KEY ornatılǵan bolsın, I bólimin kór). Server qayta iske qosıldı.
2. Brauzerde **http://localhost:3000/demo-store.html** ash. Bul "dúkan" beti.
3. "Sebetke qosıw" qasında **Kiyip kóriw** túymesi payda boladı. Bas.
4. Modal ashıladı: **▶ Baslaw** bas, kamera ruxsatın ber. Kiyim (kók futbolka) kiyindiriledi.
5. Sessiya 60 sekundtan keyin toqtaydı. Esap `server/usage.json` ge jazıladı.

**Haqıyqıy dúkanǵa qosıw:** `server/stores.json` ge dúkandı qos (kilt, `origins`: saytınıń adresi), hám dúkan saytına tek mına qatardı qos:
`<script src="https://SIZIŃ-DOMEN/widget/tryon-widget.js" data-key="DUKAN-KILTI" defer></script>`
Haqıyqıy saytqa qosıw ushın server internette (HTTPS) bolıwı kerek. Kamera tek HTTPS/localhost ta isleydi.
Tolıq joba: `docs/STORE-INTEGRATION.md`.

## K. Qálegen brauzerde ashıw (Yandex emes)
**A) Live Server (tiykarǵı sayt, `web/index.html`):**
1. VS Code da **Ctrl+,** (Settings) bas.
2. Izlewge `liveServer.settings.CustomBrowser` jaz.
3. Dizimnen **chrome** (yamasa microsoft-edge, firefox) tańla.
4. Live Server di toqtatıp (tómende "Port: 5500" bas), qayta "Go Live" bas.
(Bul sazlaw `.vscode/settings.json` de de bar, biraq ol tek `tryon-platform` papkasın **File -> Open Folder** menen ashqanda isleydi.)

**B) Node server (`localhost:3000`, ai.html hám demo-store):** terminalda
```
set OPEN_BROWSER=chrome
npm start
```
Ol Chrome da demo-store ti ashadı. Edge ushın `msedge`, Firefox ushın `firefox`.

**C) Hámme programma ushın:** Windows -> Settings -> Apps -> Default apps -> Chrome ti "Default" qıl.

## L. 5-bósqısh: Realistik AR v2 (tegin, AI sız)
Ne ózgerdi: kiyim endi **12 nuqta menen denege sozıladı** (yelke, moyın, qoltıq, jeń, etek), jeńler qoldıń qozǵalısına ergesedi, kiyim **adam konturı ishinde** qıyıladı (hawada salbırap turmaydı), jańa realistik futbolka súwretleri (maq'al, tigis, kólenke).
1. Jańa zip ti ashıp, eski papkanıń ornına qoy. `web/index.html` ti ash, **Ctrl+F5**.
2. Eń jaqsı nátiyje: jaqtı bólme, ústińde ápiwayı sıǵımlı futbolka, kamera ayaq-moyın deńgeyinde, yelke hám qoldıń joqarı bólegi kórinsin.
3. Futbolka ústinde ele eski kiyim kórinse: sazlawlar `catalog.json` da: `widen` (0.04 -> 0.08 keńeytedi), `lenK` (uzınlıq), `sleeve` (jeń uzınlıǵı 0.4-0.7), `sleeveW` (jeń keńligi).
4. Qıyıw jaman isleytuǵın bolsa, ekrandaǵı "Adam konturı boyınsha qıyıw" belgisin alıp taslap kór.
5. **Haqıyqıy futbolka fotosı:** fonın al (Photopea), `tools/anchor-picker.html` di Live Server menen ash, 12 nuqtanı tártip penen bas, shıqqan `"mesh":[...]` qatardı `catalog.json` ge jańa kiyim retinde qos.

## M. 6-bósqısh: Óz kiyimiń kórinbey qalıwı (jabıw + búklem)
Ne qosıldı:
1. **Eski kiyimdi jabıw:** dene hám jeń kiyimniń reńi menen toltırıladı, sonıń ústine kiyim sızıladı. Jeń qısqa bolsa, ilekler **ózińizdiń teri reńińiz** benen jabıladı (reń jaq betinen alınadı).
2. **Búklem/kólenke ótkeriw:** óz kiyimińizdegi búklemler hám kólenkeler jańa kiyimge ótkeriledi, sonıń ushın kiyim videoǵa "jabısıp" kórinedi.
3. Ekrandaǵı eki belgi: **Kontur boyınsha qıyıw** hám **Búklem/kólenke ótkeriw**. Salıstırıw ushın ońlap/óshirip kór.

Qádemler: jańa zip -> eski papkanıń ornına -> `web/index.html` Live Server -> **Ctrl+F5**.
Sazlaw: `catalog.json`: `sleeve` 0.5 (qısqa jeń), 1.0 ge jaqın (uzın jeń, teri bolmaydı), `sleeveW` (jeń keńligi), `widen`.
E� jaqsı nátiyje: jaqtı bólme, kamera aldında tik, qollar denege ásire jabıspasın, aq/ápiwayı fon.

## N. 7-bósqısh: Foto rejim (CatVTON, haqıyqıy AI, 0 so'm)
Tolıq qádemler: `generative/README.md`. Qısqasha: saytta **📸 Foto saqlaw** -> Colab da `generative/catvton_tryon.ipynb` ti ash -> T4 GPU -> Shift+Enter -> nátiyje `results.zip`.

## O. 8-bósqısh: Kiyimdi tartıp sozıw + silueti boyınsha toltırıw
Ne ózgerdi:
1. **Yarım-sheńber "dóńgelekler" qátesi dúzetildi** (jeń toltırıwı).
2. Eski kiyim endi **adam silueti boyınsha** tolıq jabıladı (yelkeden etekke shekem), qollar hám ilekler óz kúyinde qaladı.
3. Kiyim yelkede keńirek hám joqarıraq otıradı.
4. **✋ Kiyimdi tartıw rejimi:** belgini qos, 12 nuqta (nómerli dóńgelekler) kórinedi. Nuqtanı sichqansha menen (yamasa barmaq penen) sürip kiyimdi sozıw/qısıw/jıljıtıw múmkin. "Eki tárepi birdey" belgisi shep-oń táreptı birge ózgertedi. Ózgerisler yelke keńligine salıstırmalı saqlanadı, sonıń ushın adam burılsa, jaqınlasa kiyim ústinde qaladı.
5. **↺ Qaytarıw:** ózgerislerdi óshiredi. **📋 Sazlawdı kóshiriw:** `"offsets":[...]` qatardı alıp, `catalog.json` degi kiyimge qos, saqlap qoyıladı.
Qádemler: jańa zip -> eski papkanıń ornına -> `web/index.html` Live Server -> Ctrl+F5. Belgilerdiń hámmesi (kontur, búklem) qosılǵan bolsın.

## P. 9-bósqısh: Óz futbolkańızdı qosıw (avtomat)
1. Tegis jerge (aq qaǵaz/tósek) futbolkanı jayıp, **joqarıdan, aldınan** foto al. Fon **bir reńli**, futbolka fonnan ayrıqsha reńde bolsın (aq futbolka + aq fon bolmaydı).
2. Saytta **➕ Futbolka qosıw** bas, fotonı tańla. Fon avtomat alınadı, 12 nuqta avtomat tabıladı.
3. Fon jaman alınsa: **"Fondı alıw dárejesi"** sliderin ózgert (úlken = kóbirek alıp taslaydı).
4. Nuqtalar qáte jerde tursa, olardı sürip túzet. Tártibi: 1-2 moyın, 3-4 yelke, 5-6 jeńniń sırtqı ushı, 7-8 jeńniń ishki ushı, 9-10 qoltıq, 11-12 etek.
5. Atın jaz, **➕ Qosıw** bas. Futbolka katalogqa túsedi hám brauzerde saqlanadı (qayta ashqanda joǵalmaydı).
6. Óshiriw: kiyim kartasına **ońǵı túyme** menen bas.
Shegi: tegis futbolkalar (qısqa jeń) ushın tańlanǵan. Uzın jeń, kapyushon, kóp reńli fon ushın qolda túzetiw kerek.

## Q. Fondı kesiw: avtomat hám AI (sapalı)
**1) Avtomat kesiw:** foto tańlasań, bir reńli fon (aq/kúlreń) chetten alınadı. Tez, internet kerek emes. Fon kúrdeli, futbolka fonǵa uqsas reńde bolsa, qáte bolıwı múmkin: sonda ekran ⚠ eskertedi.
**2) 🎯 AI kesiw (Google MediaPipe Interactive Segmenter, tegin):**
1. "🎯 AI kesiw" rejimin tańla.
2. Futbolkanıń ústine 🟢 menen bas. Jasıl boyaw kórinedi.
3. Kesim qáte bolsa: ortıqsha bólekke 🔴 (fon) menen bas, jetispegen bólekke 🟢 (futbolka) menen bas. Hár basqanda qayta esaplanadı.
4. "🔧 Nuqtalardı túzetiw" rejimine qayt, nuqtalardı tekser, ➕ Qosıw.
Birinshi AI kesiwde model internetten júklenedi (bir neshe MB). Isleymese, avtomat kesiw jumıs isleyveredi.
"↺ Avtomat" túymesi hámmesin qaytadan baslaydı.
