// Kóp dúkanlı (multi-tenant) server: statik fayllar + dúkan sessiyası + Decart tokeni + súwret proksi + paydalanıw esabı.
import http from "node:http";
import fs from "node:fs/promises";
import fsSync from "node:fs";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { exec } from "node:child_process";
import { createDecartClient } from "@decartai/sdk";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../web");
const stores = JSON.parse(fsSync.readFileSync(path.join(here, "stores.json"), "utf8"));
const usageFile = path.join(here, "usage.json");
let usage = {}; try { usage = JSON.parse(fsSync.readFileSync(usageFile, "utf8")); } catch {}
const SECRET = process.env.SESSION_SECRET || "dev-secret-ózgert";
const client = process.env.DECART_API_KEY ? createDecartClient({ apiKey: process.env.DECART_API_KEY }) : null;
const types = { ".html": "text/html", ".js": "text/javascript", ".json": "application/json", ".svg": "image/svg+xml",
  ".png": "image/png", ".jpg": "image/jpeg", ".css": "text/css", ".glb": "model/gltf-binary" };

const month = () => new Date().toISOString().slice(0, 7);
const used = k => usage[k]?.[month()] || 0;
const mac = b => crypto.createHmac("sha256", SECRET).update(b).digest("base64url");
const sign = o => { const b = Buffer.from(JSON.stringify(o)).toString("base64url"); return b + "." + mac(b); };
function verify(t) {
  try { const [b, s] = (t || "").split("."); if (!crypto.timingSafeEqual(Buffer.from(s), Buffer.from(mac(b)))) return null;
    const o = JSON.parse(Buffer.from(b, "base64url")); return o.exp > Date.now() ? o : null; } catch { return null; }
}
const allOrigins = new Set(Object.values(stores).flatMap(s => s.origins));
const json = (res, code, o) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
async function body(req) { let d = ""; for await (const c of req) d += c; return d ? JSON.parse(d) : {}; }

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://x"), origin = req.headers.origin;
    if (origin && allOrigins.has(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Session");
      res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    }
    if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }

    if (req.method === "POST" && url.pathname === "/api/session") {       // widget (dúkan betinen) shaqıradı
      const { key } = await body(req), st = stores[key];
      if (!st || !st.origins.includes(origin)) return json(res, 403, { error: "domen ruxsat etilmegen" });
      const remain = st.aiSecondsPerMonth - used(key);
      if (remain <= 0) return json(res, 402, { error: "aylıq limit tawsıldı" });
      const max = Math.min(st.maxSessionSec || 60, remain);
      const proto = req.headers["x-forwarded-proto"] || "http";
      const s = sign({ k: key, exp: Date.now() + 10 * 60e3, max });
      return json(res, 200, { embedUrl: `${proto}://${req.headers.host}/embed.html?s=${s}&max=${max}` });
    }
    if (req.method === "POST" && url.pathname === "/api/tokens") {
      const sess = req.headers["x-session"] ? verify(req.headers["x-session"]) : null;
      const dev = !req.headers["x-session"] && req.headers.host.startsWith("localhost");   // ai.html sınaǵı
      if (!sess && !dev) return json(res, 401, { error: "sessiya joq" });
      if (!client) return json(res, 500, { error: "DECART_API_KEY ornatılmaǵan" });
      return json(res, 200, await client.tokens.create());
    }
    if (req.method === "POST" && url.pathname === "/api/usage") {
      const sess = verify(req.headers["x-session"]); if (!sess) return json(res, 401, {});
      const { seconds } = await body(req), sec = Math.max(0, Math.min(Number(seconds) || 0, sess.max + 5));
      usage[sess.k] ??= {}; usage[sess.k][month()] = used(sess.k) + sec;
      fsSync.writeFileSync(usageFile, JSON.stringify(usage, null, 2));
      return json(res, 200, { used: used(sess.k) });
    }
    if (req.method === "GET" && url.pathname === "/api/garment") {          // kiyim súwretin proksi (ruxsat etilgen xostlar)
      const sess = verify(url.searchParams.get("s")); if (!sess) return json(res, 401, {});
      const st = stores[sess.k], u = new URL(url.searchParams.get("url"));
      const hosts = [...st.origins.map(o => new URL(o).host), ...(st.imageHosts || [])];
      if (!/^https?:$/.test(u.protocol) || !hosts.includes(u.host)) return json(res, 403, { error: "xost ruxsat etilmegen" });
      const r = await fetch(u, { redirect: "error" }), type = r.headers.get("content-type") || "";
      const buf = Buffer.from(await r.arrayBuffer());
      if (!type.startsWith("image/") || buf.length > 5e6) return json(res, 415, { error: "súwret emes yamasa úlken" });
      res.writeHead(200, { "Content-Type": type }); return res.end(buf);
    }
    let p = decodeURIComponent(url.pathname); if (p.endsWith("/")) p += "index.html";
    const f = path.join(root, p);
    if (!f.startsWith(root)) { res.writeHead(403); return res.end(); }
    const data = await fs.readFile(f);
    res.writeHead(200, { "Content-Type": types[path.extname(f)] || "application/octet-stream" }); res.end(data);
  } catch (e) { res.writeHead(e.code === "ENOENT" ? 404 : 500); res.end(String(e.message)); }
}).listen(3000, () => {
  console.log("Tayar: http://localhost:3000   Demo dúkan: /demo-store.html   AI: /ai.html");
  // Brauzerdi tańlaw: OPEN_BROWSER=chrome (yamasa msedge, firefox). Windows ushın.
  if (process.env.OPEN_BROWSER) exec(`start ${process.env.OPEN_BROWSER} http://localhost:3000/demo-store.html`);
});
