import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

// Procedural 3D zatlar (birlik: sm; bet keńligi ~14 sm). Ornına .glb qoyıwǵa boladı.
const PROC = {
  glasses(c = "#111") {
    const g = new THREE.Group();
    const m = new THREE.MeshStandardMaterial({ color: c, roughness: .4, metalness: .3 });
    for (const s of [-1, 1]) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(2.2, .2, 12, 40), m); ring.position.x = s * 3.3; g.add(ring);
      const lens = new THREE.Mesh(new THREE.CircleGeometry(2.2, 32),
        new THREE.MeshBasicMaterial({ color: "#223", transparent: true, opacity: .28, side: THREE.DoubleSide }));
      lens.position.x = s * 3.3; g.add(lens);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(.25, .25, 9), m); arm.position.set(s * 5.5, 0, -4.5); g.add(arm);
    }
    const br = new THREE.Mesh(new THREE.CylinderGeometry(.18, .18, 2.2, 8), m); br.rotation.z = Math.PI / 2; g.add(br);
    return g;
  },
  cap(c = "#1d4ed8") {
    const g = new THREE.Group();
    const m = new THREE.MeshStandardMaterial({ color: c, roughness: .8, side: THREE.DoubleSide });
    const dome = new THREE.Mesh(new THREE.SphereGeometry(8, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), m);
    dome.scale.set(1, .85, 1.1); g.add(dome);
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(6.8, 6.8, .4, 32, 1, false, -Math.PI / 2, Math.PI), m);
    brim.scale.z = 1.5; brim.position.set(0, .2, 2.5); g.add(brim);
    return g;
  }
};

async function build(item) {
  let o;
  if (item.model.startsWith("procedural:")) o = PROC[item.model.slice(11)](item.color);
  else o = (await new GLTFLoader().loadAsync(item.model)).scene;
  const w = new THREE.Group(); w.add(o); return w;
}

export class Head3D {
  constructor(canvas) {
    this.r = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    this.scene = new THREE.Scene();
    this.cam = new THREE.PerspectiveCamera(63, 4 / 3, 1, 1000);
    this.scene.add(new THREE.AmbientLight(0xffffff, .9));
    const d = new THREE.DirectionalLight(0xffffff, 1.2); d.position.set(0, 10, 20); this.scene.add(d);
    this.anchor = new THREE.Group(); this.anchor.matrixAutoUpdate = false; this.anchor.visible = false;
    this.scene.add(this.anchor); this.slots = {};
  }
  resize(w, h) { this.r.setSize(w, h, false); this.cam.aspect = w / h; this.cam.updateProjectionMatrix(); }
  setFov(f) { this.cam.fov = f; this.cam.updateProjectionMatrix(); }
  async wear(slot, item) {
    if (this.slots[slot]) { this.anchor.remove(this.slots[slot]); this.slots[slot] = null; }
    if (!item) return;
    const o = await build(item); this.anchor.add(o); this.slots[slot] = o; this.place(item);
  }
  place(item) {
    const o = this.slots[item.slot]; if (!o) return;
    o.position.set(...item.offset); o.scale.setScalar(item.scale);
  }
  update(matrix) {                       // matrix: 16 san (bas pozasi) yamasa null
    if (matrix) { this.anchor.matrix.fromArray(matrix); this.anchor.matrixWorldNeedsUpdate = true; }
    this.anchor.visible = !!matrix;
    this.r.render(this.scene, this.cam);
  }
}
