// Futbolka qosıw quralı: foto -> fonın alıw -> 12 nuqtanı avtomat tabıw -> qolda túzetiw -> katalogqa qosıw.
// Barlıǵı klassikalıq kompyuter kóriw algoritmleri (neyron tor emes), brauzerde isleydi.
import { TRIS } from "./overlay.js";

const median = a => a.slice().sort((x, y) => x - y)[a.length >> 1];

function removeBg(src, w, h, tol) {                 // bir reńli fondı chetten "toltırıw" (flood fill)
  const p = src.data, bg = new Uint8Array(w * h), rs = [], gs = [], bs = [];
  const push = (x, y) => { const i = (y * w + x) * 4; rs.push(p[i]); gs.push(p[i + 1]); bs.push(p[i + 2]); };
  for (let x = 0; x < w; x++) { push(x, 0); push(x, h - 1); } for (let y = 0; y < h; y++) { push(0, y); push(w - 1, y); }
  const R = median(rs), G = median(gs), B = median(bs);
  const dist = i => Math.hypot(p[i * 4] - R, p[i * 4 + 1] - G, p[i * 4 + 2] - B), st = [];
  const tryp = i => { if (!bg[i] && dist(i) < tol) { bg[i] = 1; st.push(i); } };
  for (let x = 0; x < w; x++) { tryp(x); tryp((h - 1) * w + x); } for (let y = 0; y < h; y++) { tryp(y * w); tryp(y * w + w - 1); }
  while (st.length) { const i = st.pop(), x = i % w, y = (i / w) | 0; if (x > 0) tryp(i - 1); if (x < w - 1) tryp(i + 1); if (y > 0) tryp(i - w); if (y < h - 1) tryp(i + w); }
  const a = new Uint8Array(w * h); for (let i = 0; i < w * h; i++) a[i] = bg[i] ? 0 : 255;
  return keepLargest(erode(a, w, h), w, h);
}
function erode(a, w, h) {
  const o = new Uint8Array(a);
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y * w + x; if (a[i] && (!a[i - 1] || !a[i + 1] || !a[i - w] || !a[i + w])) o[i] = 0; }
  return o;
}
function keepLargest(a, w, h) {
  const lab = new Int32Array(w * h), st = []; let best = 0, bestN = 0, id = 0;
  for (let s = 0; s < w * h; s++) {
    if (!a[s] || lab[s]) continue; id++; let n = 0; st.push(s); lab[s] = id;
    while (st.length) { const i = st.pop(); n++; const x = i % w, y = (i / w) | 0;
      for (const j of [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1]) if (j >= 0 && a[j] && !lab[j]) { lab[j] = id; st.push(j); } }
    if (n > bestN) { bestN = n; best = id; }
  }
  const o = new Uint8Array(w * h); for (let i = 0; i < w * h; i++) o[i] = lab[i] === best ? 255 : 0; return o;
}

// Silueti boyınsha 12 nuqta: NL NR SL SR SOL SOR SIL SIR AL AR HL HR (shep = súwrettiń shep tárepi)
function detectMesh(a, w, h) {
  const rl = new Int16Array(h).fill(-1), rr = new Int16Array(h).fill(-1);
  let top = h, bot = -1, L = w, R = -1;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (a[y * w + x]) { if (rl[y] < 0) rl[y] = x; rr[y] = x; }
  for (let y = 0; y < h; y++) if (rl[y] >= 0) { top = Math.min(top, y); bot = Math.max(bot, y); L = Math.min(L, rl[y]); R = Math.max(R, rr[y]); }
  if (bot < 0) return null;
  const H = bot - top + 1, W = R - L + 1, cx = (L + R) / 2, wid = y => rl[y] < 0 ? 0 : rr[y] - rl[y] + 1;
  const y0 = Math.floor(top + 0.70 * H), y1 = Math.floor(bot - 0.03 * H), ys = [];
  for (let y = y0; y <= y1; y++) if (rl[y] >= 0) ys.push(y);
  const tw = median(ys.map(wid)), Bl = median(ys.map(y => rl[y])), Br = median(ys.map(y => rr[y]));
  const armpit = x => {                                                                   // qoltıq: dene shetinen sál sırtta jeńniń tómengi shegarası
    x = Math.max(0, Math.min(w - 1, Math.round(x))); let y = top; while (y <= bot && !a[y * w + x]) y++;
    if (y > bot) return Math.floor(top + 0.35 * H); while (y + 1 <= bot && a[(y + 1) * w + x]) y++; return y;
  };
  const yAL = armpit(Bl - 0.03 * tw), yAR = armpit(Br + 0.03 * tw);
  const colTop = x => { for (let y = top; y <= bot; y++) if (a[y * w + x]) return y; return top; };
  const sx = 0.05 * tw, SLx = Math.max(L, Math.round(Bl - sx)), SRx = Math.min(R, Math.round(Br + sx));
  let NL = [Math.round(cx - 0.12 * W), top], NR = [Math.round(cx + 0.12 * W), top];
  const yN = Math.min(bot, top + Math.max(2, Math.round(0.012 * H))); let g0 = -1, g1 = -1;
  let bestRun = 0, run0 = -1;                                                              // moyın oyıǵı: qatar ishindegi eń uzın bos aralıq
  for (let x = rl[yN]; x <= rr[yN] + 1; x++) {
    const empty = x <= rr[yN] && !a[yN * w + x];
    if (empty && run0 < 0) run0 = x;
    if (!empty && run0 >= 0) { if (x - run0 > bestRun) { bestRun = x - run0; g0 = run0; g1 = x - 1; } run0 = -1; }
  }
  if (g0 >= 0 && bestRun > 0.08 * W) { NL = [g0 - 1, yN]; NR = [g1 + 1, yN]; }
  const sleeve = side => {
    const lim = side < 0 ? Bl - 0.04 * tw : Br + 0.04 * tw; let outer = null, inner = null;
    for (let y = top; y <= bot; y++) {
      const x = side < 0 ? rl[y] : rr[y]; if (x < 0 || (side < 0 ? x >= lim : x <= lim)) continue;
      if (!outer || (side < 0 ? x < outer[0] : x > outer[0])) outer = [x, y];
      if (!inner || y >= inner[1]) inner = [x, y];
    }
    return [outer || [side < 0 ? L : R, Math.round(top + 0.25 * H)], inner || [side < 0 ? Math.round(L + 0.15 * W) : Math.round(R - 0.15 * W), Math.round(top + 0.35 * H)]];
  };
  const [SOL, SIL] = sleeve(-1), [SOR, SIR] = sleeve(1);
  return [NL, NR, [SLx, colTop(SLx)], [SRx, colTop(SRx)], SOL, SOR, SIL, SIR, [Math.round(Bl), yAL], [Math.round(Br), yAR], [Math.round(Bl), bot], [Math.round(Br), bot]];
}

const feather = (a, w, h) => {                       // 3x3 ortasha: jumsaq shet
  const o = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let t = 0, n = 0;
    for (let dy = -1; dy <= 1; dy++) { const yy = y + dy; if (yy < 0 || yy >= h) continue;
      for (let dx = -1; dx <= 1; dx++) { const xx = x + dx; if (xx < 0 || xx >= w) continue; t += a[yy * w + xx]; n++; } }
    o[y * w + x] = t / n;
  }
  return o;
};

// AI kesiw: MediaPipe Interactive Segmenter (Google, tegin, brauzerde isleydi). Birinshi paydalanǵanda model júklenedi.
let segP = null;
function loadSeg() {
  segP ??= (async () => {
    const mp = await import("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/+esm");
    const vision = await mp.FilesetResolver.forVisionTasks("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm");
    const seg = await mp.InteractiveSegmenter.createFromOptions(vision, { baseOptions: { modelAssetPath:
      "https://storage.googleapis.com/mediapipe-models/interactive_segmenter_v2/magic_touch/int8/latest/interactive_segmentation.task" } });
    return { seg, BM: mp.BrushMode };
  })();
  segP.catch(() => { segP = null; });
  return segP;
}

export function openGarmentTool(onAdd) {
  const dlg = document.createElement("dialog");
  dlg.style.cssText = "width:min(94vw,600px);border:0;border-radius:12px;padding:16px;font:15px system-ui";
  dlg.innerHTML = `<h3 style="margin:0 0 6px">➕ Futbolka qosıw</h3>
    <p style="margin:0 0 8px;font-size:14px">Tegis jayılǵan futbolkanıń aldınan foto. <b>1)</b> Fon avtomat kesiledi. Qáte bolsa <b>2)</b> "🎯 AI kesiw" rejiminde futbolkaǵa bas. <b>3)</b> Nuqtalardı túzet, qos.</p>
    <input type="file" accept="image/*" id="gf"><br>
    <label style="display:block;margin:8px 0">Avtomat kesiw dárejesi <input type="range" id="gt" min="10" max="120" value="45"></label>
    <div style="margin:6px 0;font-size:14px;line-height:2">
      <label><input type="radio" name="gm" value="pts" checked> 🔧 Nuqtalardı túzetiw</label>
      <label style="margin-left:8px"><input type="radio" name="gm" value="ai"> 🎯 AI kesiw (basıp kórset)</label><br>
      <span>AI rejimde bas: </span>
      <label><input type="radio" name="gp" value="1" checked> 🟢 bul futbolka</label>
      <label style="margin-left:8px"><input type="radio" name="gp" value="0"> 🔴 bul fon</label>
      <button id="gr" style="margin-left:8px">↺ Avtomat</button></div>
    <canvas id="gc" style="width:100%;background:repeating-conic-gradient(#ddd 0 25%,#fff 0 50%) 0 0/16px 16px;border-radius:8px;touch-action:none"></canvas>
    <p id="gs" style="font-size:14px;margin:6px 0">Súwret tańlań.</p>
    <input id="gn" placeholder="Atı (mısalı: Aq futbolka)" style="width:100%;padding:8px;margin:4px 0 8px;box-sizing:border-box">
    <button id="ga" disabled style="padding:8px 14px">➕ Qosıw</button> <button id="gx" style="padding:8px 14px">Jabıw</button>`;
  document.body.append(dlg); dlg.showModal();
  const $ = id => dlg.querySelector("#" + id), cv = $("gc"), c = cv.getContext("2d");
  const val = n => dlg.querySelector(`input[name=${n}]:checked`).value;
  let src = null, srcC = null, a = null, mesh = null, cut = null, tint = null, W = 0, Hh = 0, drag = -1, pts = [];
  const close = () => { dlg.close(); dlg.remove(); }; $("gx").onclick = close;

  function render() {
    c.clearRect(0, 0, W, Hh); if (!srcC) return;
    if (val("gm") === "ai") {
      c.drawImage(srcC, 0, 0); if (tint) c.drawImage(tint, 0, 0);
      const k = Math.max(1, W / 400);
      for (const p of pts) { c.beginPath(); c.arc(p.x, p.y, 7 * k, 0, 7); c.fillStyle = p.pos ? "#16a34a" : "#dc2626"; c.fill(); c.strokeStyle = "#fff"; c.lineWidth = 2 * k; c.stroke(); }
      return;
    }
    if (cut) c.drawImage(cut, 0, 0);
    if (!mesh) return; const k = Math.max(1, W / 400);
    c.strokeStyle = "rgba(15,118,110,.9)"; c.lineWidth = k; c.font = `${11 * k}px sans-serif`; c.textAlign = "center";
    for (const [i, j, l] of TRIS) { c.beginPath(); c.moveTo(...mesh[i]); c.lineTo(...mesh[j]); c.lineTo(...mesh[l]); c.closePath(); c.stroke(); }
    mesh.forEach((p, i) => { c.beginPath(); c.arc(p[0], p[1], 9 * k, 0, 7); c.fillStyle = "#fff"; c.fill(); c.stroke(); c.fillStyle = "#0f766e"; c.fillText(i + 1, p[0], p[1] + 4 * k); });
  }
  function build(bin, chk) {                                // ekilik maska -> qırqılǵan súwret, jasıl kórsetkish, 12 nuqta, sapa tekseriwi
    a = bin; const soft = feather(a, W, Hh), p = src.data;
    const o = new ImageData(new Uint8ClampedArray(p), W, Hh), t = new ImageData(W, Hh); let area = 0;
    for (let i = 0; i < W * Hh; i++) { o.data[i * 4 + 3] = soft[i]; if (a[i]) { area++; t.data.set([22, 163, 74, 110], i * 4); } }
    cut = document.createElement("canvas"); cut.width = W; cut.height = Hh; cut.getContext("2d").putImageData(o, 0, 0);
    tint = document.createElement("canvas"); tint.width = W; tint.height = Hh; tint.getContext("2d").putImageData(t, 0, 0);
    mesh = detectMesh(a, W, Hh); $("ga").disabled = !mesh;
    let low = false;                                    // fon hám futbolka reńi uqsas pa? (avtomat kesiw isenimsiz bolıwı múmkin)
    if (chk) {
      const fg = [0, 0, 0], bgc = [0, 0, 0]; let nf = 0, nb = 0;
      for (let i = 0; i < W * Hh; i += 3) { const t = a[i] ? fg : bgc; t[0] += p[i * 4]; t[1] += p[i * 4 + 1]; t[2] += p[i * 4 + 2]; a[i] ? nf++ : nb++; }
      if (nf && nb) low = Math.hypot(fg[0] / nf - bgc[0] / nb, fg[1] / nf - bgc[1] / nb, fg[2] / nf - bgc[2] / nb) < 50;
    }
    let bd = 0, cnt = 0;
    for (let x = 0; x < W; x++) { cnt += 2; bd += (a[x] ? 1 : 0) + (a[(Hh - 1) * W + x] ? 1 : 0); }
    for (let y = 0; y < Hh; y++) { cnt += 2; bd += (a[y * W] ? 1 : 0) + (a[y * W + W - 1] ? 1 : 0); }
    $("gs").textContent = !mesh ? "Futbolka tabılmadı. 🎯 AI kesiw rejiminde futbolkaǵa bas."
      : bd / cnt > 0.04 ? "⚠ Kesilgen bólek súwret shetine tiyip tur: fon tolıq alınbaǵan shıǵar. 🎯 AI kesiw rejiminde futbolkaǵa (🟢) hám fonǵa (🔴) bas."
      : area / (W * Hh) < 0.04 ? "⚠ Futbolka tım kishi tabıldı. 🎯 AI kesiw menen qayta kórsetiń."
      : low ? "⚠ Futbolka hám fon reńi uqsas: avtomat kesiw isenimsiz. 🎯 AI kesiw rejimin paydalan (futbolkaǵa 🟢, fonǵa 🔴 bas)."
      : "✓ Kesildi, 12 nuqta tabıldı. Kerek bolsa 🔧 rejiminde nuqtanı sürip túzet, keyin ➕ Qosıw.";
  }
  function auto() {                                    // avtomat: alpha bar bolsa sonı, bolmasa bir reńli fondı alıw
    if (!src) return; pts = []; const p = src.data; let hasA = false;
    for (let x = 0; x < W; x++) if (p[x * 4 + 3] < 200 || p[((Hh - 1) * W + x) * 4 + 3] < 200) { hasA = true; break; }
    let bin;
    if (hasA) { bin = new Uint8Array(W * Hh); for (let i = 0; i < W * Hh; i++) bin[i] = p[i * 4 + 3] > 127 ? 255 : 0; bin = keepLargest(bin, W, Hh); }
    else bin = removeBg(src, W, Hh, +$("gt").value);
    build(bin, true); render();
  }
  async function aiClick(x, y) {
    pts.push({ x, y, pos: val("gp") === "1" }); $("gs").textContent = "AI kesip atır… (birinshi ret model júklenedi, internet kerek)";
    try {
      const { seg, BM } = await loadSeg(); seg.setImage(srcC);
      const m = seg.segment(pts.map(q => ({ brushMode: q.pos ? BM.POSITIVE : BM.NEGATIVE, point: [{ x: q.x / W, y: q.y / Hh }], isCompleted: true })));
      const f = m.getAsFloat32Array(), mw = m.width, mh = m.height, bin = new Uint8Array(W * Hh);
      for (let yy = 0; yy < Hh; yy++) for (let xx = 0; xx < W; xx++) bin[yy * W + xx] = f[((yy * mh / Hh) | 0) * mw + ((xx * mw / W) | 0)] > 0.5 ? 255 : 0;
      m.close?.(); build(keepLargest(bin, W, Hh));
    } catch (e) { pts.pop(); $("gs").textContent = "AI kesiw islemedi: " + e.message + ". Avtomat kesiw dárejesin ózgertip kór."; console.error(e); }
    render();
  }
  $("gf").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    const img = new Image(); img.src = URL.createObjectURL(f); await img.decode();
    const s = Math.min(1, 640 / Math.max(img.width, img.height)); W = cv.width = Math.round(img.width * s); Hh = cv.height = Math.round(img.height * s);
    srcC = document.createElement("canvas"); srcC.width = W; srcC.height = Hh; const t = srcC.getContext("2d", { willReadFrequently: true });
    t.drawImage(img, 0, 0, W, Hh); src = t.getImageData(0, 0, W, Hh);
    $("gn").value ||= f.name.replace(/\.[^.]+$/, ""); auto();
  };
  $("gt").onchange = auto; $("gr").onclick = auto;
  dlg.querySelectorAll("input[name=gm]").forEach(r => r.onchange = render);
  const pos = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * W / r.width, (e.clientY - r.top) * Hh / r.height]; };
  cv.onpointerdown = e => {
    const [x, y] = pos(e);
    if (val("gm") === "ai") { if (src) aiClick(Math.round(x), Math.round(y)); return; }
    if (!mesh) return; let b = -1, bd = 1e9;
    mesh.forEach((p, i) => { const d = Math.hypot(p[0] - x, p[1] - y); if (d < bd) { bd = d; b = i; } });
    if (bd < 30 * W / cv.getBoundingClientRect().width) { drag = b; cv.setPointerCapture(e.pointerId); }
  };
  cv.onpointermove = e => { if (drag < 0) return; const [x, y] = pos(e); mesh[drag] = [Math.round(x), Math.round(y)]; render(); };
  cv.onpointerup = () => { drag = -1; };
  $("ga").onclick = () => {                           // bbox boyınsha qırqıp, katalogqa beremiz
    let x0 = W, x1 = 0, y0 = Hh, y1 = 0;
    for (let y = 0; y < Hh; y++) for (let x = 0; x < W; x++) if (a[y * W + x]) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    const pad = 6, out = document.createElement("canvas"); out.width = x1 - x0 + 1 + 2 * pad; out.height = y1 - y0 + 1 + 2 * pad;
    out.getContext("2d").drawImage(cut, x0 - pad, y0 - pad);
    onAdd({ id: "u" + Date.now(), name: $("gn").value.trim() || "Futbolka", image: out.toDataURL("image/png"),
            mesh: mesh.map(([x, y]) => [x - x0 + pad, y - y0 + pad]) });
    close();
  };
}
