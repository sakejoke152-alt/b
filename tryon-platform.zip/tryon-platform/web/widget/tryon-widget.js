// Dúkan saytına bir qatar menen qosıladı:
// <script src="https://BIZIŃ-DOMEN/widget/tryon-widget.js" data-key="DUKAN-KILTI" defer></script>
// Ixtiyariy: data-image, data-prompt, data-target (túyme qoyılatuǵın selector)
(() => {
  const me = document.currentScript, base = new URL(me.src).origin, key = me.dataset.key;
  const meta = p => document.querySelector(`meta[property="${p}"]`)?.content;
  function product() {
    let title = me.dataset.title || meta("og:title") || document.title, image = me.dataset.image || meta("og:image");
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {   // schema.org Product
      try { const j = JSON.parse(s.textContent), p = [].concat(j["@graph"] || j).find(x => x["@type"] === "Product");
        if (p) { title = me.dataset.title || p.name || title; image = me.dataset.image || [].concat(p.image)[0] || image; } } catch {}
    }
    const abs = image ? new URL(image, location.href).href : null;
    const prompt = me.dataset.prompt || `Substitute the current top with ${title}`;   // keyin: LLM menen jaqsılaw
    return { image: abs, prompt };
  }
  const btn = document.createElement("button");
  btn.textContent = "👕 Kiyip kóriw";
  btn.style.cssText = "padding:12px 18px;border:0;border-radius:10px;background:#0f766e;color:#fff;font:600 16px system-ui;cursor:pointer;z-index:9999";
  const target = me.dataset.target && document.querySelector(me.dataset.target);
  if (target) target.after(btn); else { btn.style.cssText += "position:fixed;right:16px;bottom:16px;box-shadow:0 4px 14px rgba(0,0,0,.3)"; document.body.append(btn); }

  btn.onclick = async () => {
    const pr = product(); if (!pr.image) return alert("Kiyim súwreti tabılmadı");
    btn.disabled = true;
    try {
      const r = await fetch(`${base}/api/session`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key }) });
      const j = await r.json(); if (!r.ok) throw new Error(j.error || r.status);
      const q = `&img=${encodeURIComponent(pr.image)}&prompt=${encodeURIComponent(pr.prompt)}`;
      const wrap = document.createElement("div");
      wrap.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:99999;display:flex;align-items:center;justify-content:center";
      wrap.innerHTML = `<div style="position:relative;width:min(92vw,720px);height:min(88vh,620px);background:#fff;border-radius:12px;overflow:hidden">
        <button aria-label="Jabıw" style="position:absolute;right:8px;top:8px;z-index:2;border:0;border-radius:50%;width:36px;height:36px;font-size:20px;cursor:pointer">×</button>
        <iframe src="${j.embedUrl}${q}" allow="camera" style="width:100%;height:100%;border:0"></iframe></div>`;
      const close = () => { wrap.remove(); document.removeEventListener("keydown", esc); };
      const esc = e => e.key === "Escape" && close();
      wrap.querySelector("button").onclick = close; document.addEventListener("keydown", esc);
      document.body.append(wrap);
    } catch (e) { alert("Try-on ashılmadı: " + e.message); }
    btn.disabled = false;
  };
})();
