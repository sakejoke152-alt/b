// Nuqtalardıń titirewin azaytıw (EMA). a: 0.2 jumsaq ... 0.7 tez
export class Smooth {
  constructor(a = 0.4) { this.a = a; this.p = null; }
  update(q) {
    if (!this.p) this.p = { x: q.x, y: q.y };
    else { this.p.x += this.a * (q.x - this.p.x); this.p.y += this.a * (q.y - this.p.y); }
    return this.p;
  }
}
