import { startCamera } from "./camera.js";
import { createPose } from "./pose.js";
import { createFace } from "./face.js";
import { Head3D } from "./head3d.js";
import { Smooth } from "./smooth.js";
import { drawGarment, meshWarp, TRIS } from "./overlay.js";
import { openGarmentTool } from "./garment-tool.js";
import { saveGarment, deleteGarment, listGarments } from "./store.js";

const $ = id => document.getElementById(id);
const video = $("video"), canvas = $("out"), ctx = canvas.getContext("2d");
const status = $("status"), catalogEl = $("catalog");
const gl = new Head3D($("gl"));
const sm = Array.from({ length: 12 }, () => new Smooth(0.45)), sH = new Smooth(0.3);
const worn = {};
let geo = null, skin = { r: 200, g: 160, b: 140 };
const tmpC = document.createElement("canvas"), tmpx = tmpC.getContext("2d");
let pose = null, face = null, light = 1, n = 0, tuned = null, lastW = 0, fps = 0, t0 = performance.now(), fr = 0, maskReady = false;

const layer = document.createElement("canvas"), lctx = layer.getContext("2d");
const maskC = document.createElement("canvas"), mctx = maskC.getContext("2d");
const probe = document.createElement("canvas"); probe.width = 32; probe.height = 24;
const pctx = probe.getContext("2d", { willReadFrequently: true });
function estimateLight() {
  pctx.drawImage(video, 0, 0, 32, 24);
  const d = pctx.getImageData(0, 0, 32, 24).data; let s = 0;
  for (let i = 0; i < d.length; i += 4) s += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  return Math.min(1.15, Math.max(0.7, 0.65 + 0.55 * (s / (d.length / 4) / 255)));
}

function tuneFor(it) {
  tuned = it; $("ty").value = it.offset[1]; $("tz").value = it.offset[2]; $("ts").value = it.scale;
  $("tout").textContent = `"offset":[${it.offset}],"scale":${it.scale}`;
}
for (const id of ["ty", "tz", "ts", "tf"]) $(id).oninput = () => {
  if (!tuned) return;
  tuned.offset[1] = +$("ty").value; tuned.offset[2] = +$("tz").value; tuned.scale = +$("ts").value;
  gl.setFov(+$("tf").value); gl.place(tuned);
  $("tout").textContent = `"offset":[${tuned.offset}],"scale":${tuned.scale}   (FOV ${$("tf").value})\nBulardı catalog.json ge kóshir.`;
};

async function toggle(it, btn) {
  const same = worn[it.slot] === it;
  document.querySelectorAll(`[data-slot="${it.slot}"]`).forEach(x => x.setAttribute("aria-pressed", "false"));
  if (same) { worn[it.slot] = null; if (it.model) await gl.wear(it.slot, null); return; }
  worn[it.slot] = it; btn.setAttribute("aria-pressed", "true");
  if (it.model) { await gl.wear(it.slot, it); tuneFor(it); }
}
function addItem(it, removable) {
  if (it.anchors || it.mesh) { it.img = new Image(); it.img.src = it.image; }
  if (it.mesh) { it.meshPts = it.mesh.map(([x, y]) => ({ x, y })); it.offs = (it.offsets || Array.from({ length: 12 }, () => [0, 0])).map(a => [...a]); }
  const b = document.createElement("button");
  b.className = "item"; b.dataset.slot = it.slot; b.setAttribute("aria-pressed", "false");
  b.innerHTML = `<img src="${it.image}" alt=""><span>${it.name}</span>`;
  b.onclick = () => toggle(it, b); catalogEl.append(b);
  if (removable) b.oncontextmenu = async e => {              // ońǵı túyme: óshiriw
    e.preventDefault();
    if (confirm(`"${it.name}" óshirilsin be?`)) { await deleteGarment(it.id); if (worn[it.slot] === it) worn[it.slot] = null; b.remove(); }
  };
  return b;
}
async function loadCatalog() {
  const items = await (await fetch("catalog.json")).json();
  for (const it of items) addItem(it);
  try { for (const g of await listGarments()) addItem({ slot: "top", sleeve: 0.5, sleeveW: 0.3, widen: 0.07, lenK: 1.1, torsoRatio: 1.6, ...g }, true); }
  catch (e) { console.warn("IndexedDB:", e); }
  catalogEl.firstChild.click();
}
$("addg").onclick = () => openGarmentTool(async g => {
  await saveGarment(g);
  addItem({ slot: "top", sleeve: 0.5, sleeveW: 0.3, widen: 0.07, lenK: 1.1, torsoRatio: 1.6, ...g }, true).click();
});

function detect() {                                   // dene nuqtaları + kontur maskası
  let lm = null;
  pose.detectForVideo(video, performance.now(), r => {
    lm = r.landmarks[0];
    const m = r.segmentationMasks?.[0];
    if (m) {
      const mw = m.width, mh = m.height; if (maskC.width !== mw) { maskC.width = mw; maskC.height = mh; }
      const f = m.getAsFloat32Array(), id = mctx.createImageData(mw, mh);
      for (let i = 0; i < f.length; i++) id.data[i * 4 + 3] = f[i] * 255;
      mctx.putImageData(id, 0, 0); maskReady = true;
    }
  });
  return lm;
}

// Ekrandaǵı 12 maqset nuqta (tártibi: NL NR SL SR SOL SOR SIL SIR AL AR HL HR)
function targets(lm, w, h, it) {
  const P = i => ({ x: (1 - lm[i].x) * w, y: lm[i].y * h }), ok = (i, t = 0.5) => lm[i].visibility > t;
  const A = P(11), B = P(12), M = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 };
  const sw = Math.hypot(B.x - A.x, B.y - A.y), u = { x: (B.x - A.x) / sw, y: (B.y - A.y) / sw }, nn = { x: -u.y, y: u.x };
  const at = (p, ku, kn) => ({ x: p.x + (u.x * ku + nn.x * kn) * sw, y: p.y + (u.y * ku + nn.y * kn) * sw });
  const wd = it.widen ?? 0.04, lenK = it.lenK ?? 1.1, tr = it.torsoRatio ?? 1.6;
  const SL = at(A, -0.08, -0.06), SR = at(B, 0.08, -0.06);
  const NL = at(M, -0.20, -0.12), NR = at(M, 0.20, -0.12);
  const AL = at(A, 0.05 - wd, 0.30), AR = at(B, -0.05 + wd, 0.30);
  let HL, HR;
  if (ok(23, 0.6) && ok(24, 0.6)) {
    const hl = P(23), hr = P(24);
    HL = at({ x: A.x + (hl.x - A.x) * lenK, y: A.y + (hl.y - A.y) * lenK }, -wd, 0);
    HR = at({ x: B.x + (hr.x - B.x) * lenK, y: B.y + (hr.y - B.y) * lenK }, wd, 0);
  } else { HL = at(M, -(0.40 + wd), tr); HR = at(M, 0.40 + wd, tr); }
  const sleeve = (S, ei, out) => {                       // out: -1 shep, +1 oń
    let a = ok(ei) ? (() => { const e = P(ei), d = Math.hypot(e.x - S.x, e.y - S.y) || 1; return { x: (e.x - S.x) / d, y: (e.y - S.y) / d, len: d }; })()
      : (() => { const x = nn.x + u.x * out * 0.15, y = nn.y + u.y * out * 0.15, d = Math.hypot(x, y); return { x: x / d, y: y / d, len: sw * 0.9 }; })();
    const c = { x: S.x + a.x * a.len * (it.sleeve ?? 0.5), y: S.y + a.y * a.len * (it.sleeve ?? 0.5) };
    let p = { x: -a.y, y: a.x }; if (p.x * u.x * out + p.y * u.y * out < 0) p = { x: -p.x, y: -p.y };
    const half = sw * (it.sleeveW ?? 0.30) / 2;
    return [{ x: c.x + p.x * half, y: c.y + p.y * half }, { x: c.x - p.x * half, y: c.y - p.y * half }, c];
  };
  const [SOL, SIL, cL] = sleeve(SL, 13, -1), [SOR, SIR, cR] = sleeve(SR, 14, 1);
  geo = { SL, SR, NL, NR, HL, HR, cL, cR, sw, P, ok, u, nn, M };
  const pts = [NL, NR, SL, SR, SOL, SOR, SIL, SIR, AL, AR, HL, HR].map((p, i) => {   // qolda tartılǵan ózgerisler (dene sistemasında)
    const o = it.offs?.[i] ?? [0, 0];
    return { x: p.x + (u.x * o[0] + nn.x * o[1]) * sw, y: p.y + (u.y * o[0] + nn.y * o[1]) * sw };
  });
  geo.raw = pts;
  return pts.map((p, i) => ({ ...sm[i].update(p) }));
}

const sctx = document.createElement("canvas").getContext("2d", { willReadFrequently: true });
sctx.canvas.width = sctx.canvas.height = 1;
function sampleSkin(lm) {                               // jaq betinen teri reńin al
  if (!(lm[0].visibility > 0.5)) return;
  let r = 0, g = 0, b = 0;
  for (const e of [7, 8]) {
    const X = (lm[0].x + (lm[e].x - lm[0].x) * 0.5) * video.videoWidth, Y = (lm[0].y + (lm[e].y - lm[0].y) * 0.5 + 0.02) * video.videoHeight;
    sctx.drawImage(video, X - 5, Y - 5, 10, 10, 0, 0, 1, 1);
    const d = sctx.getImageData(0, 0, 1, 1).data; r += d[0]; g += d[1]; b += d[2];
  }
  skin = { r: skin.r * .8 + r / 2 * .2, g: skin.g * .8 + g / 2 * .2, b: skin.b * .8 + b / 2 * .2 };
}
function avgColor(img) {
  const c = document.createElement("canvas"); c.width = c.height = 16;
  const g = c.getContext("2d", { willReadFrequently: true }); g.drawImage(img, 0, 0, 16, 16);
  const d = g.getImageData(0, 0, 16, 16).data; let r = 0, gg = 0, b = 0, a = 0;
  for (let i = 0; i < d.length; i += 4) { const al = d[i + 3]; r += d[i] * al; gg += d[i + 1] * al; b += d[i + 2] * al; a += al; }
  return a ? `rgb(${r / a | 0},${gg / a | 0},${b / a | 0})` : "#888";
}
// Adamnıń óz kiyimindegi búklem/kólenke: jaqtılıqtıń joqarı jiyilikli bólegi kiyimge ótkeriledi
const SW = 192, SH = 144, sh = document.createElement("canvas"), shx = sh.getContext("2d", { willReadFrequently: true });
sh.width = SW; sh.height = SH;
const sg = new Float32Array(SW * SH), tp = new Float32Array(SW * SH), bl = new Float32Array(SW * SH);
function box(src, dst, w, h, r, vert) {
  const len = vert ? h : w, cnt = vert ? w : h, st = vert ? w : 1, ln = vert ? 1 : w;
  for (let k = 0; k < cnt; k++) {
    const o = k * ln; let acc = 0;
    for (let x = -r; x <= r; x++) acc += src[o + Math.min(len - 1, Math.max(0, x)) * st];
    for (let x = 0; x < len; x++) { dst[o + x * st] = acc / (2 * r + 1); acc += src[o + Math.min(len - 1, x + r + 1) * st] - src[o + Math.max(0, x - r) * st]; }
  }
}
function updateShade() {
  shx.drawImage(video, 0, 0, SW, SH);
  const d = shx.getImageData(0, 0, SW, SH), p = d.data;
  for (let i = 0; i < SW * SH; i++) sg[i] = 0.299 * p[i * 4] + 0.587 * p[i * 4 + 1] + 0.114 * p[i * 4 + 2];
  box(sg, tp, SW, SH, 7, false); box(tp, bl, SW, SH, 7, true);
  for (let i = 0; i < SW * SH; i++) {
    const v = 128 + Math.max(-110, Math.min(110, (sg[i] - bl[i]) / (bl[i] + 25) * 300));
    p[i * 4] = p[i * 4 + 1] = p[i * 4 + 2] = v; p[i * 4 + 3] = 255;
  }
  shx.putImageData(d, 0, 0);
}

let lastDst = null;
function drawMesh(it, lm, w, h) {
  const dst = targets(lm, w, h, it), g = geo; lastDst = dst;
  if (n % 15 === 0) sampleSkin(lm);
  if (!it.avg && it.img.complete && it.img.naturalWidth) it.avg = avgColor(it.img);
  const useMask = maskReady && $("clip").checked;
  lctx.clearRect(0, 0, w, h);
  lctx.fillStyle = it.avg || "#888"; lctx.lineCap = "butt"; lctx.lineJoin = "round";
  // 1) Eski kiyimdi jabıw
  const HC = { x: (g.HL.x + g.HR.x) / 2, y: (g.HL.y + g.HR.y) / 2 };
  const C = (b, ku, kn) => ({ x: b.x + (g.u.x * ku + g.nn.x * kn) * g.sw, y: b.y + (g.u.y * ku + g.nn.y * kn) * g.sw });
  lctx.beginPath();
  if (useMask) [C(g.M, -3, -0.08), C(g.M, 3, -0.08), C(HC, 3, 0), C(HC, -3, 0)].forEach((p, i) => i ? lctx.lineTo(p.x, p.y) : lctx.moveTo(p.x, p.y));
  else [g.NL, g.NR, g.SR, g.HR, g.HL, g.SL].forEach((p, i) => { const q = { x: g.M.x + (p.x - g.M.x) * 1.08, y: g.M.y + (p.y - g.M.y) * 1.03 }; i ? lctx.lineTo(q.x, q.y) : lctx.moveTo(q.x, q.y); });
  lctx.closePath(); lctx.fill();
  if ((it.sleeve ?? 0.5) < 0.9) {                         // qısqa jeń: ilekler teri reńi menen
    lctx.strokeStyle = `rgb(${skin.r | 0},${skin.g | 0},${skin.b | 0})`; lctx.lineWidth = g.sw * 0.22;
    for (const [c, e, wr] of [[g.cL, 13, 15], [g.cR, 14, 16]]) if (g.ok(e) && g.ok(wr)) {
      const E = g.P(e), W = g.P(wr); lctx.beginPath(); lctx.moveTo(c.x, c.y); lctx.lineTo(E.x, E.y); lctx.lineTo(W.x, W.y); lctx.stroke();
    }
  }
  // 2) Kiyimniń ózi
  meshWarp(lctx, it.img, it.meshPts, dst);
  // 3) Tek adam konturı ishinde; qollar óz kúyinde qaladı
  if (useMask) {
    lctx.save(); lctx.globalCompositeOperation = "destination-in"; lctx.filter = "blur(1.5px)";
    lctx.translate(w, 0); lctx.scale(-1, 1); lctx.drawImage(maskC, 0, 0, w, h); lctx.restore();
    lctx.save(); lctx.globalCompositeOperation = "destination-out";
    for (const [wr, ix] of [[15, 19], [16, 20]]) if (g.ok(wr, 0.4)) {
      const W = g.P(wr), I = g.ok(ix, 0.3) ? g.P(ix) : W, c = { x: (W.x + I.x) / 2, y: (W.y + I.y) / 2 };
      lctx.beginPath(); lctx.arc(c.x, c.y, Math.hypot(W.x - I.x, W.y - I.y) * 0.8 + g.sw * 0.12, 0, 7); lctx.fill();
    }
    lctx.restore();
  }
  // 4) Adamnıń búklemi/kólenkesi kiyimge
  const useShade = $("shade").checked;
  if (useShade) {
    updateShade(); tmpx.clearRect(0, 0, w, h); tmpx.imageSmoothingQuality = "high";
    tmpx.save(); tmpx.translate(w, 0); tmpx.scale(-1, 1); tmpx.drawImage(sh, 0, 0, w, h); tmpx.restore();
    tmpx.globalCompositeOperation = "destination-in"; tmpx.drawImage(layer, 0, 0); tmpx.globalCompositeOperation = "source-over";
  }
  ctx.save(); ctx.filter = `brightness(${light})`;
  ctx.shadowColor = "rgba(0,0,0,.30)"; ctx.shadowBlur = 12; ctx.shadowOffsetY = 3;
  ctx.drawImage(layer, 0, 0); ctx.restore();
  if (useShade) { ctx.save(); ctx.globalCompositeOperation = "soft-light"; ctx.drawImage(tmpC, 0, 0); ctx.restore(); }
  // 5) Sazlaw rejimi: tor hám tutqıshlar
  if ($("edit").checked) {
    ctx.save(); ctx.strokeStyle = "rgba(15,118,110,.9)"; ctx.lineWidth = 1.5; ctx.font = "11px sans-serif"; ctx.textAlign = "center";
    for (const [a, b, c] of TRIS) { ctx.beginPath(); ctx.moveTo(dst[a].x, dst[a].y); ctx.lineTo(dst[b].x, dst[b].y); ctx.lineTo(dst[c].x, dst[c].y); ctx.closePath(); ctx.stroke(); }
    dst.forEach((p, i) => { ctx.beginPath(); ctx.arc(p.x, p.y, 9, 0, 7); ctx.fillStyle = "#fff"; ctx.fill(); ctx.stroke(); ctx.fillStyle = "#0f766e"; ctx.fillText(i + 1, p.x, p.y + 4); });
    ctx.restore();
  }
}
function drawFlat(it, lm, w, h) {                        // eski 3 nuqtalı usıl (mesh joq kiyimler ushın)
  const A = { x: (1 - lm[11].x) * w, y: lm[11].y * h }, B = { x: (1 - lm[12].x) * w, y: lm[12].y * h };
  const M = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 }, sw = Math.hypot(B.x - A.x, B.y - A.y);
  const Hs = sH.update({ x: M.x + (-(B.y - A.y) / sw) * sw * (it.torsoRatio ?? 1.6), y: M.y + ((B.x - A.x) / sw) * sw * (it.torsoRatio ?? 1.6) });
  drawGarment(ctx, it.img, it.anchors, A, B, Hs, { light });
}
function drawTop(w, h) {
  const lm = detect(); const it = worn.top;
  if (!(lm && lm[11].visibility > 0.5 && lm[12].visibility > 0.5)) return false;
  if (++n % 10 === 0) light = estimateLight();
  it.mesh ? drawMesh(it, lm, w, h) : drawFlat(it, lm, w, h);
  return true;
}

function frame() {
  if (video.readyState >= 2) {
    const w = canvas.width = video.videoWidth, h = canvas.height = video.videoHeight;
    if (w !== lastW) { gl.resize(w, h); layer.width = tmpC.width = w; layer.height = tmpC.height = h; lastW = w; }
    ctx.save(); ctx.translate(w, 0); ctx.scale(-1, 1); ctx.drawImage(video, 0, 0, w, h); ctx.restore();
    let ok = true;
    if (worn.top) ok = drawTop(w, h);
    const has3d = Object.values(worn).some(i => i && i.model);
    let m = null;
    if (has3d) m = face.detectForVideo(video, performance.now()).facialTransformationMatrixes?.[0]?.data ?? null;
    gl.update(m);
    if (++fr % 30 === 0) { fps = Math.round(30000 / (performance.now() - t0)); t0 = performance.now(); }
    status.textContent = (ok && (!has3d || m) ? "Tayar" : "Betińiz/yelkeńiz kórinsin") + ` · ${fps} FPS`;
  }
  requestAnimationFrame(frame);
}

// Kiyimdi tutıp tartıw: nuqtalardı sürip kiyimdi sozıw/qısıw. Ózgerisler dene sistemasında (yelke keńligine salıstırmalı),
// sonıń ushın adam burılsa yamasa jaqınlasa da kiyim sol kúyinde "ústinde turadı".
const toC = e => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * canvas.width / r.width, y: (e.clientY - r.top) * canvas.height / r.height }; };
let drag = -1; canvas.style.touchAction = "none";
canvas.addEventListener("pointerdown", e => {
  const it = worn.top; if (!$("edit").checked || !lastDst || !it?.offs) return;
  const p = toC(e), k = canvas.width / canvas.getBoundingClientRect().width; let b = -1, bd = 1e9;
  lastDst.forEach((q, i) => { const d = Math.hypot(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; b = i; } });
  if (bd < 45 * k) { drag = b; canvas.setPointerCapture(e.pointerId); }
});
canvas.addEventListener("pointermove", e => {
  if (drag < 0 || !geo?.raw) return;
  const it = worn.top, g = geo, p = toC(e), q = g.raw[drag], dx = p.x - q.x, dy = p.y - q.y;
  const du = (dx * g.u.x + dy * g.u.y) / g.sw, dn = (dx * g.nn.x + dy * g.nn.y) / g.sw;
  it.offs[drag][0] += du; it.offs[drag][1] += dn; q.x += dx; q.y += dy;
  if ($("sym").checked) { const j = drag ^ 1; it.offs[j][0] -= du; it.offs[j][1] += dn; }
});
canvas.addEventListener("pointerup", () => { drag = -1; });
$("reset").onclick = () => { const it = worn.top; if (it?.offs) it.offs = Array.from({ length: 12 }, () => [0, 0]); };
$("copyfit").onclick = async () => {
  const it = worn.top; if (!it?.offs) return;
  const t = `"offsets":${JSON.stringify(it.offs.map(a => a.map(v => +v.toFixed(3))))}`;
  try { await navigator.clipboard.writeText(t); status.textContent = "Kóshirildi. catalog.json degi kiyimge qos."; } catch { status.textContent = t; }
};

$("snap").onclick = () => {                           // kiyimsiz taza kadrdı PNG qılıp saqlaydı
  const c = document.createElement("canvas"); c.width = video.videoWidth; c.height = video.videoHeight;
  c.getContext("2d").drawImage(video, 0, 0);
  c.toBlob(b => { const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "person.png"; a.click(); });
};

try {
  await loadCatalog();
  await startCamera(video);
  [pose, face] = await Promise.all([createPose(), createFace()]);
  frame();
} catch (e) {
  status.textContent = "Qátelik: " + e.message + " (kamera ruxsatın hám localhost/HTTPS tekseriń)";
  console.error(e);
}
