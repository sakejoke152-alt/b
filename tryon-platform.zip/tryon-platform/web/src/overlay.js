// 3 nuqta (L, R, H) -> ekrandaǵı 3 nuqta. Affine: kiyim yelkege hám boyǵa qaray sozıladı.
// A,B: ekrandaǵı yelkeler. Hs: ekrandaǵı etek ortası. light: jaqtılıq koeffitsienti.
export function drawGarment(ctx, img, an, A, B, Hs, opt = {}) {
  const [lx, ly] = an.L, [rx, ry] = an.R, [hx, hy] = an.H;
  const ux = rx - lx, uy = ry - ly, vx = hx - lx, vy = hy - ly;
  const det = ux * vy - uy * vx;
  if (!det) return;
  const tx = B.x - A.x, ty = B.y - A.y, wx = Hs.x - A.x, wy = Hs.y - A.y;
  const a = (tx * vy - wx * uy) / det, b = (ty * vy - wy * uy) / det;
  const c = (-tx * vx + wx * ux) / det, d = (-ty * vx + wy * ux) / det;
  const e = A.x - (a * lx + c * ly), f = A.y - (b * lx + d * ly);
  ctx.save();
  ctx.filter = `brightness(${opt.light ?? 1}) blur(0.4px)`;
  ctx.shadowColor = "rgba(0,0,0,.35)"; ctx.shadowBlur = 14; ctx.shadowOffsetY = 4;
  ctx.transform(a, b, c, d, e, f);
  ctx.drawImage(img, 0, 0);
  ctx.restore();
}

// ---- Mesh warp: kiyimdi 12 nuqta boyınsha denege sozıw (úshmúyeshlik-úshmúyeshlik) ----
export const TRIS = [[0,1,3],[0,3,2],[2,3,9],[2,9,8],[8,9,11],[8,11,10],[2,4,6],[2,6,8],[3,5,7],[3,7,9]];

function affine(s, d) {
  const ux = s[1].x - s[0].x, uy = s[1].y - s[0].y, vx = s[2].x - s[0].x, vy = s[2].y - s[0].y;
  const det = ux * vy - uy * vx; if (!det) return null;
  const tx = d[1].x - d[0].x, ty = d[1].y - d[0].y, wx = d[2].x - d[0].x, wy = d[2].y - d[0].y;
  const a = (tx * vy - wx * uy) / det, b = (ty * vy - wy * uy) / det;
  const c = (-tx * vx + wx * ux) / det, dd = (-ty * vx + wy * ux) / det;
  return [a, b, c, dd, d[0].x - (a * s[0].x + c * s[0].y), d[0].y - (b * s[0].x + dd * s[0].y)];
}
export function meshWarp(g, img, src, dst, tris = TRIS) {
  for (const [i, j, k] of tris) {
    const s = [src[i], src[j], src[k]], d = [dst[i], dst[j], dst[k]], m = affine(s, d); if (!m) continue;
    const cx = (d[0].x + d[1].x + d[2].x) / 3, cy = (d[0].y + d[1].y + d[2].y) / 3;
    g.save(); g.beginPath();
    d.forEach((p, t) => { const dx = p.x - cx, dy = p.y - cy, L = Math.hypot(dx, dy) || 1;
      const x = p.x + dx / L * 0.7, y = p.y + dy / L * 0.7; t ? g.lineTo(x, y) : g.moveTo(x, y); });
    g.closePath(); g.clip(); g.transform(...m); g.drawImage(img, 0, 0); g.restore();
  }
}
