// Paydalanıwshı qosqan futbolkalar brauzerde (IndexedDB) saqlanadı.
const open = () => new Promise((res, rej) => {
  const r = indexedDB.open("tryon", 1);
  r.onupgradeneeded = () => r.result.createObjectStore("garments", { keyPath: "id" });
  r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
});
async function tx(mode, fn) {
  const db = await open();
  return new Promise((res, rej) => {
    const t = db.transaction("garments", mode), q = fn(t.objectStore("garments"));
    t.oncomplete = () => res(q?.result); t.onerror = () => rej(t.error);
  });
}
export const saveGarment = g => tx("readwrite", s => s.put(g));
export const deleteGarment = id => tx("readwrite", s => s.delete(id));
export const listGarments = () => tx("readonly", s => s.getAll());
